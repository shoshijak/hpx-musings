// Shoshana Jakobovits
// April 2017

#include <hpx/hpx.hpp>
#include <hpx/hpx_init.hpp>
#include <hpx/include/iostreams.hpp>
#include <hpx/include/lcos.hpp>
#include <cmath>

#define N_COMP 1e8
#define N_REC 4     //! 2 is sufficient to prove the point

//! BABY TASK
//! simulates some heavy computation step
void baby_task(const int sec){
  hpx::cout << "--- Baby-task starting, simulating heavy computation\n";
  for(size_t i(0); i<N_COMP; i++)
    double a = 4.5*exp(i)*(1./sin(i));
  hpx::cout << "--- Baby-task finished executing\n";
}

//! PAPA TASK
//! is called recursively
//! spawns baby-tasks
hpx::future<void> papa_task(const unsigned int Nrec){

  hpx::cout << "Papa-task starting, with level of recursion "
            << Nrec << "\n";

  hpx::future<void> baby_task_future = hpx::async(
    [Nrec](){
      hpx::cout << "Baby-task launched from level of recursion "
                << Nrec << "\n";
      baby_task(N_SLEEP);
    }
  );

  if(Nrec <= 1){ // termination condition
    hpx::cout << "Papa-task: termination condition met\n";
    return baby_task_future;
  }

  // recursion
  hpx::cout << "Recursing down to level " << Nrec-1 << "...\n";
  std::vector<hpx::future<void>> spawned_baby_task_future;
  spawned_baby_task_future.reserve(2);
  spawned_baby_task_future.push_back(std::move(baby_task_future));
  spawned_baby_task_future.push_back(std::move(hpx::async(
    [Nrec]()
    {
      papa_task(Nrec-1);
    }
  )));

  hpx::cout << "Recursion level " << Nrec-1 << " launched\n";
  return hpx::when_all(spawned_baby_task_future);
}

//! SETUP STEP
//! Simulates a setup step needed at the beginning of a program
bool setup_step(){

  hpx::cout << "Starting turtle-test... launching Papa-task\n";
  hpx::future<void> papa_task_future = papa_task(N_REC);
  hpx::cout << "Papa-task returned\n";

  papa_task_future.wait();
  hpx::cout << "\n\n\n"
            << "*******************************************************\n"
            << "***         Papa-task future is ready               ***\n"
            << "***         Setup-step completed                    ***\n"
            << "*******************************************************\n";
  return true;
}

//! MAIN
int hpx_main(int argc, char* argv[])
{

  hpx::cout << "\n\nTesting the turtles-all-the-way-down-theory : \n"
            << "Simulating some setup step needed in the beginning of a program :\n"
            << "all Papa-tasks and Baby-tasks must complete before we move on to the next step."
            << "\n\n\n";
  if(setup_step()){
    hpx::cout << "Setup step completed, we can move on to whatever the next step is now\n\n\n\n";
  }

  return hpx::finalize();

}

int main(int argc, char* argv[])
{
  return hpx::init(argc, argv);
}
