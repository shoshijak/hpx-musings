// Shoshana Jakobovits
// April 2017

#include <hpx/hpx.hpp>
#include <hpx/hpx_init.hpp>
#include <hpx/include/iostreams.hpp>
#include <hpx/include/lcos.hpp>
#include <cmath>

#define N_REC 5     //! 3 is sufficient to prove the point

//! REC TASK - is called recursively
hpx::future<void> rec_task(const unsigned int Nrec){
  hpx::cout << "Recursive-task: execution starting. Level of recursion = "
            << Nrec << "\n";

  if(Nrec <= 1){ // termination condition
    hpx::cout << "Recursive-task: termination condition met\n";
    return hpx::make_ready_future();
  }

  // recursion
  hpx::cout << "Recursive-task: recursing down to level " << Nrec-1 << "...\n";
  hpx::future<void> spawned_rec_task_future(std::move(hpx::async(
    [Nrec](){
      rec_task(Nrec-1);
    })));

  hpx::cout << "Recursive-task: recursion level " << Nrec-1 << " launched\n";
  return spawned_rec_task_future;
}

// SETUP STEP
// Simulates a setup step needed at the beginning of a program
void setup_step(){
  hpx::cout << "Setup-step: launching the Papa-task of all Recursive-tasks\n";
  hpx::future<void> papa_task_future = rec_task(N_REC);
  hpx::cout << "Setup-step: Papa-task returned. Waiting for future of Papa-task to be ready.\n";

  papa_task_future.wait();
  hpx::cout << "\n"
            << "*******************************************************\n"
            << "***         Papa-task                               ***\n"
            << "***         (future of all recursive tasks)         ***\n"
            << "***         is ready                                ***\n"
            << "*******************************************************\n";
}

// HPX-MAIN
int hpx_main(int argc, char* argv[])
{
  hpx::cout << "\nMain: testing the turtles-all-the-way-down-theory:\n"
            << "Simulating some setup step needed in the beginning of a program:\n"
            << "-- The setup-step involves a call to recursive function\n"
            << "-- All rec-tasks must complete before we move on to the next step.\n\n";

  setup_step();
  hpx::cout << "Main: Setup-step completed, we can move on to whatever the next step is now\n\n";

  return hpx::finalize();
}

int main(int argc, char* argv[])
{
  return hpx::init(argc, argv);
}
